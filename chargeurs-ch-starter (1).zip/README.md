# Chargeurs.ch Starter

Projet initial React + Vite + Supabase + TailwindCSS.

## Démarrage

```bash
npm install
npm run dev
```

Créer un fichier `.env` à partir de `.env.example` et y insérer vos clés Supabase.
